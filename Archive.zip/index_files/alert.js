/*
 alert.js
 To add emergency announcements to pages in Drupal WebCMS
 Note: you should not edit this file;
 it should stay empty because we manage alerts in Drupal WebCMS
 If Drupal WebCMS is down, then Akamai takes over
 */
